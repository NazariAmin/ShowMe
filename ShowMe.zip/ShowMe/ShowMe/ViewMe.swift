//
//  ViewMe.swift
//  ShowMe
//
//  Created by Nazari on 1/25/17.
//  Copyright © 2017 Puia. All rights reserved.
//

import Foundation
import UIKit

class ViewMe : UIViewController{
    
    @IBOutlet weak var Label: UILabel!
    
    var LabelText = String()
    
    override func viewDidLoad() {
        Label.text = LabelText
    }
}
