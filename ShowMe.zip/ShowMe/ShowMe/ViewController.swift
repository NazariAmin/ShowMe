//
//  ViewController.swift
//  ShowMe
//
//  Created by Nazari on 1/25/17.
//  Copyright © 2017 Puia. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var TextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.TextField.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            TextField.resignFirstResponder()
        return(true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let DestViewController = segue.destination as! ViewMe
            DestViewController.LabelText = TextField.text!
    }
    


}

