//
//  ViewTwo.swift
//  ShowMe
//
//  Created by Wasim Ahmad on 1/25/17.
//  Copyright © 2017 Wasim Ahmad. All rights reserved.
//

import Foundation
import UIKit

class ViewTwo : UIViewController {
 
    @IBOutlet weak var Label: UILabel!
    var LabelText = String()
    
    override func viewDidLoad() {
        
        Label.text = LabelText
        
    }
}
